# AI Meme Coin Hunter v1

Scanner de descoperire și triere pentru pool-uri noi de pe Solana, folosind API-ul public GeckoTerminal.

## Funcționalități
- Preia pool-uri noi de pe Solana.
- Filtre pentru lichiditate, volum 1h și vechime.
- Scor euristic 0–100, cu explicația scorului.
- Clasament și export CSV.
- Link către DEX Screener pentru verificare suplimentară.

## Rulare locală
Necesită Python 3.10 sau mai nou.

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Publicare în cloud (Streamlit Community Cloud)
1. Încarcă toate fișierele din arhivă în repository-ul GitHub.
2. Intră pe https://share.streamlit.io/ și conectează GitHub.
3. Alege repository-ul, branch-ul principal și fișierul `app.py`.
4. Apasă Deploy.

## Limitări și siguranță
- Versiunea 1 este un instrument de cercetare, nu un sistem de tranzacționare.
- Nu conectează portofel și nu execută cumpărări/vânzări.
- Scorul este euristic și nu reprezintă consultanță financiară sau o predicție.
- API-ul public poate limita cererile sau poate returna date incomplete.
- Verifică manual contractul, lichiditatea blocată, distribuția deținătorilor și riscul de rug pull înainte de orice decizie.
